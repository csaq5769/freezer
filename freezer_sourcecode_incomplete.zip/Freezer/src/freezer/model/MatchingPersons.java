package freezer.model;

//user chooses his/her date here
public class MatchingPersons {
	
	//need list of person
	public void selectPerson() {
		//...
	}
	
	public void sendMessage() {
		//...
	}
}
