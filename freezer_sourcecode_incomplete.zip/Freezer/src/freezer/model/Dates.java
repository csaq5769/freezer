package freezer.model;

import java.util.List;

public class Dates {
	private List<String> interests;
	private List<String> region;
	private List<String> persons;
	
	//maybe compare interests of persons in this class
	
	//compare chosen regions
	
	//print out matching persons
}
