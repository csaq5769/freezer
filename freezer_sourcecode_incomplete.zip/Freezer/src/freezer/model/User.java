package freezer.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class User {
	private String email;
	private String username;
	private String password;
	private Integer age;
	private Gender gender;
	private String country;
	private boolean loggedIn = false;
	
	//lists from other classes
	List<String> regions; //from Lift
	List<String> interests; //from Interests
	
	//for comparing interests
	private List<Map<String, List<String>>> userInterests = new ArrayList<Map<String, List<String>>>(); //the final list
	private static Map<String, List<String>> userInterest = new HashMap<String, List<String>>(); //one instance of the map to store in the above map
	private List<String> chosenInterests = new ArrayList<>();
	
	
	
/*information person has to type in --> move to controller!!
	//constructor if user is alredy registrated on freeser
	public User(String username, String password) {
		this.username = username;
		this.password = password;
		
		this.loggedIn = true;
	}
	//constructor if it is a new user
	public User(String email, String username, String password, Integer age, Gender gender, String country) {
		this.email = email;
		this.username = username;
		this.password = password;
		this.age = age;
		this.gender = gender;
		this.country = country;
		
		this.loggedIn = true;
	}
*/
	
	//choose couple of predefined interests - chosenInterests.add
	public List<String> chooseInterests(List<String> interests) {
		interests = Interests.getInterests();
		String chosen;
		
		for(String choice : interests) {
			if(interests.contains(choice)) {
				chosen = choice;
				chosenInterests.add(chosen);
			} else if(choice == null) {
				System.out.println("You have to pick at least one interest!!");
			}
		}
		
		return chosenInterests;
	}
	
	//store interests-info of one user in hashmap
	public Map<String, List<String>> OneUserInterest(String username, List<String> chosenInterests) {
		userInterest.put(username, chosenInterests);
		
		return userInterest;
	}
	
	//stroe interests-info of all users in hashmap
	public List<Map<String, List<String>>> AllUserInterests(Map<String, List<String>> userInterest) {
		userInterests.add(userInterest);
		
		return userInterests;
	}
	
	//need list of lifts and regions
	public void chooseLift() {
		//...
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public static Map<String, List<String>> getUserInterest() {
		return userInterest;
	}

	public void setUserInterest(Map<String, List<String>> userInterest) {
		User.userInterest = userInterest;
	}

}
