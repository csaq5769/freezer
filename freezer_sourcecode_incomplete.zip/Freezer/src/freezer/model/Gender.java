package freezer.model;

public enum Gender {
	FEMALE,
	MALE
}
