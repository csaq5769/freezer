package freezer.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Interests {
	private static List<String> interests = new ArrayList<>();
	
	//fill list of interests - predefined in app
	public List<String> fillInterests(List<String> interests) {
		interests.add("sprot");
		interests.add("baby cats");
		interests.add("rock/metal");
		interests.add("actionmovies");
		interests.add("nature");
		interests.add("computergames");
		
		return interests;
	}
	
	Map<String, List<String>> interestsOfUser1 = User.getUserInterest();
	Map<String, List<String>> interestsOfUser2 = interestsOfUser1;
	Map<String, List<String>> allInterests = new HashMap<String, List<String>>();
	
	//compare each value of the arraylists stored in the hashmap, hashmapt to use from person: userInterest
	public void compareInterests() {
		for(Entry<String, List<String>> entry : interestsOfUser1.entrySet()) {
			for(Entry<String, List<String>> entry1 : interestsOfUser2.entrySet()) {
				if(!entry.getKey().equals(entry1.getKey())) { //only compare different keys
					if(entry.getValue().equals(entry1.getValue())) {
						allInterests.put(entry1.getKey(), entry1.getValue());
					}
				}
			}
		}
	}

	public static List<String> getInterests() {
		return interests;
	}

	public void setInterests(List<String> interests) {
		Interests.interests = interests;
	}
}
