package freezer.model;

import java.util.List;

public class Lift {
	private List<String> lifts;
	private List<String> liftsInRegion;

	//need list of lifts 
	public void eliminateOneSeats() {
		/* to do:
		 * if(column.seats.entry == 1) {
		 * 	remove(column.seats.entry);
		 * }
		 */
	}
}
